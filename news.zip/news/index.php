<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Global News Network</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>
<body>

  <div class="home">
    <header>
      <div class="logo">
        <h1>Global News Network</h1>
      </div>
      <nav>
        <ul>
          <li class="nav-item"><a class="nav-link active" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#categories">categories</a></li>
          <li class="nav-item"><a class="nav-link" href="#Contact">About Us</a></li>
          <li class="nav-item"><a class="nav-link" href="#Contact">Contact</a></li>
        </ul>
      </nav>
    </header>

    <div class="search-login">
      <form action="search.php" method="GET">
        <input type="search" name="q" placeholder="Search Here ..." />
        <button type="submit">Search</button>
      </form>
    </div>
    <div class="text">
      <h2>Welcome To Our Website<span> Global News Network</span></h2>
    </div>
  </div>
  </div>

  <div class="container">
    <aside class="sidebar">
      <h3> Trending News</h3>

      <div class="popular-news">
        <div class="news-block">
          <h4>Scholarship Program for Gaza Students</h4>
          <p>A European university has launched a full scholarship initiative to support Palestinian students.</p>
        </div>

        <div class="news-block">
          <h4>Palestinian Team Advances to National Final</h4>
          <p>Gaza Sports Club secures a place in the championship final after a dramatic semi-final win.</p>
        </div>

        <div class="news-block">
          <h4>Microsoft Unveils New AI Tool</h4>
          <p>The tech giant introduces an AI assistant designed to enhance productivity in education and business.</p>
        </div>

        <div class="news-block">
          <h4>Massive Fire Breaks Out in Industrial Zone</h4>
          <p>Emergency services are battling a large fire that erupted in a manufacturing facility overnight.</p>
        </div>

        <div class="news-block">
          <h4>Breakthrough in Cancer Research Announced</h4>
          <p>Scientists reveal a promising new treatment that targets aggressive tumor cells with high precision.</p>
        </div>

        <div class="news-block">
          <h4>Gaza Artists Exhibit Work Internationally</h4>
          <p>Young Palestinian artists gain international recognition through a London-based gallery exhibition.</p>
        </div>

        <div class="news-block">
          <h4>Cybersecurity Threat Hits Major Bank</h4>
          <p>A data breach at a regional bank exposes thousands of user accounts in a sophisticated cyberattack.</p>
        </div>

        <div class="news-block">
          <h4>UN Approves Emergency Aid for Gaza</h4>
          <p>The United Nations has announced a $100 million emergency relief package to support civilians in Gaza.</p>
        </div>

        <div class="news-block">
          <h4>New Educational Platform Launches in Arabic</h4>
          <p>A tech startup introduces an online learning portal fully localized in Arabic for students across the Middle East.</p>
        </div>

        <div class="news-block">
          <h4>Palestinian Chef Wins International Culinary Award</h4>
          <p>A chef from Ramallah takes first place at a global culinary competition in Paris.</p>
        </div>

        <div class="news-block">
          <h4>Record Heatwave Sweeps the Region</h4>
          <p>Meteorologists warn of an intense heatwave affecting several Middle Eastern countries, urging precautions.</p>
        </div>

        <div class="news-block">
          <h4>Local Volunteers Rebuild Destroyed School</h4>
          <p>Dozens of young volunteers in Khan Younis help rebuild a primary school damaged in recent shelling.</p>
        </div>

        <div class="news-block">
          <h4>Gaza University Launches Mental Health Program</h4>
          <p>The new initiative aims to support students dealing with trauma through counseling and workshops.</p>
        </div>
      </div>
    </aside>

    <main>
      <section id="breaking-news">
        <h2>Breaking News</h2>
        <article>
          <h3><a href="article.php?id=1">Major Escalation in Gaza</a></h3>
          <p>Israeli forces launched a wave of heavy airstrikes across several areas of the Gaza Strip, resulting in the deaths of dozens of civilians, including women and children. International organizations are warning of a worsening humanitarian disaster.</p>
        </article>
      </section>

      <section id="featured-articles">
        <h2 class="main-title">featured Articles</h2>
        <div class="grid">
          <div class="articles-area">
            <article class="article">
              <a href="article.php?id=1">
                <img src="Photos/moveis.jpg" alt="The latest movies on Netflix" />
                <h3 class="title">The latest movies on Netflix</h3>
               </a>
            </article>
            <article class="article">
              <a href="article.php?id=2">
                <img src="Photos/sport.jpg" alt="Who won in the Palestinian national team?" />
                <h3 class="title">Who won in the Palestinian national team?</h3>
               </a>
            </article>
            <article class="article">
              <a href="article.php?id=3">
                <img src="Photos/politics.jpg" alt="When will the war on Gaza end?" />
                <h3 class="title">When will the war on Gaza end?</h3>
               </a>
            </article>
            <article class="article">
            <a href="article.php?id=4">
              <img src="Photos/tecnology.jpg" alt="The latest Microsoft releases" />
              <h3 class="title">The latest Microsoft releases</h3>
            </a>
            </article>
          </div>
        </div>
      </section>

      <section id="latest-news">
        <h2>Latest News</h2>
        <div class="latest-news-list">
          <article class="news-item">
            <img src="Photos/OIP.jpg" alt="">
            <div class="news-content">
              <h3><a href="article.php?id=5">Education News</a></h3>
              <p>New Scholarship Program Launched for Gaza Students with International Funding</p>
            </div>
          </article>

          <article class="news-item">
            <img src="Photos/art.webp" alt="">
            <div class="news-content">
              <h3><a href="article.php?id=6">Art News</a></h3>
              <p>Palestinian Artist Wins Regional Award for Gaza-Inspired Artwork</p>
            </div>
          </article>

          <article class="news-item">
            <img src="Photos/sport.webp" alt="">
            <div class="news-content">
              <h3><a href="article.php?id=7">Sports News</a></h3>
              <p>Gaza Football Team Reaches Final of Palestinian Championship After Impressive Performance</p>
            </div>
          </article>
        </div>
      </section>

      <section id = "categories"class="category">
        <h2>Browse by Category</h2>
        <div class="category-menu">
          <a href="categories.php?id=1" class="category-item education">
            <div class="category-icon"><i class="fas fa-graduation-cap"></i></div>
            <span>Education</span>
          </a>
          <a href="categories.php?id=2" class="category-item art">
            <div class="category-icon"><i class="fas fa-palette"></i></div>
            <span>Art</span>
          </a>
          <a href="categories.php?id=3" class="category-item sports">
            <div class="category-icon"><i class="fas fa-football-ball"></i></div>
            <span>Sports</span>
          </a>
          <a href="categories.php?id=4" class="category-item tech">
            <div class="category-icon"><i class="fas fa-microchip"></i></div>
            <span>Technology</span>
          </a>
        </div>
      </section>
    </main>

  </div>
  <footer id="Contact">
    <div class="finaly">
      <div class="last-icon">
        <a href=""><i class="fab fa-facebook"></i> </a>
        <a href=""><i class="fab fa-twitter"></i> </a>
        <a href=""><i class="fab fa-google"></i> </a>
      </div>
      <h3>Copy Right 2018 © By <div class="dif">Global News</div> All Rights Reserved</h3>
    </div>
  </footer>
  
</body>
</html>
