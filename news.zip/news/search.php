<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "news_db1";

// إنشاء الاتصال
$conn = new mysqli($host, $username, $password, $database);

if (isset($_GET['q'])) {
    $searchTerm = $conn->real_escape_string($_GET['q']);
    $sql = "SELECT category_id FROM categories WHERE category_name LIKE '%$searchTerm%' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $categoryId = $row['category_id'];
        header("Location: categories.php?id=$categoryId");
        exit();
    } else {
        echo "<script>alert('لم يتم العثور على فئة بهذا الاسم'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('يرجى إدخال كلمة للبحث'); window.history.back();</script>";
}
?>
