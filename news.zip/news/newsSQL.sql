-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 15 يوليو 2025 الساعة 12:29
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news_db1`
--

-- --------------------------------------------------------

--
-- بنية الجدول `articles`
--

CREATE TABLE `articles` (
  `article_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `published_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `articles`
--

INSERT INTO `articles` (`article_id`, `title`, `content`, `image_url`, `category_id`, `author_id`, `published_date`) VALUES
(1, 'The latest movies on Netflix', 'Netflix kicked off July 2025 with a wave of fresh new movies that quickly took over the trending charts. From long-awaited sequels to original animations and international thrillers, the platform continues to cater to diverse tastes and global audiences.\n\nOne of the biggest releases this month is “Madea’s Destination Wedding”, a hilarious new chapter in Tyler Perry’s beloved franchise. Set in the Bahamas, the film brings back the iconic character Madea in a chaotic family wedding adventure. Within days of its release, it shot to #1 on Netflix’s global charts, proving the character’s enduring popularity.\n\nIn the animation world, “KPop Demon Hunters” made a bold entrance. This original musical features a girl group secretly fighting off evil spirits by night. With vibrant visuals and catchy songs, the film has become a surprise hit, especially among younger viewers and K-pop fans.\n\nFor action lovers, “The Old Guard 2” finally arrived, bringing back Charlize Theron and her immortal warrior crew for another round of high-stakes missions. The sequel builds on the success of the first film, with sharper visuals and deeper character arcs.\n\nAlso gaining buzz is “Happy Gilmore 2”, the comedic golf comeback fans have been waiting decades for. Adam Sandler reprises his classic role, with unexpected cameos and plenty of nostalgic throwbacks. The film is set to officially premiere on July 25, but early previews have already stirred excitement.\n\nInternational titles are also making waves. The German thriller “Brick” offers a tense, claustrophobic narrative set entirely inside an apartment building. Meanwhile, the Indonesian romance “Aap Jaisa Koi” explores themes of loss and connection, and “Almost Cops”, a Dutch buddy-cop comedy, adds a lighter touch to the lineup.\n\nNetflix continues to balance blockbuster content with unique indie-style films, giving subscribers a wide selection of genres and voices. Whether you\'re in the mood for laughs, drama, suspense, or something animated and musical, this month\'s releases are packed with entertainment.\n\nAs July continues, more titles are expected to drop — making it one of Netflix’s busiest months in 2025.', 'Photos/art.jpg', 2, 4, '2025-07-14 07:19:41'),
(2, 'Who won in the Palestinian national team', 'In a thrilling World Cup qualifying match held on March 25, 2025, the Palestine national football team delivered a powerful performance, defeating Iraq with a dramatic 2–1 scoreline. The match, held in front of a passionate crowd, showcased the growing strength and determination of the Palestinian squad on the international stage.\n\nThe game began with high intensity as both teams fought for early control. Iraq took the lead midway through the first half, capitalizing on a defensive error to score the opener. But Palestine responded with resilience, leveling the score just before halftime through forward Maher Al-Karmi, who tapped in a low cross with precision and composure.\n\nThe second half remained tightly contested, with both sides exchanging chances and pushing for a decisive goal. Just as the game appeared to be heading for a draw, Palestinian defender Ameed Mahajna emerged as the unlikely hero, scoring a stunning header in the 97th minute following a corner kick. The late goal sent fans into celebration and sealed an emotional victory.\n\nCoach Sami Darwish praised the team’s fighting spirit, saying, “This win means more than just three points. It’s a message of hope, unity, and strength for every Palestinian watching.”\n\nThe victory over Iraq follows another strong performance earlier this month, where Palestine defeated Kuwait 2–0 in a dominant showing. These back-to-back wins mark a promising chapter in Palestine’s World Cup qualifying campaign and have significantly boosted their standings in Group C.\n\nWith momentum on their side, the team now sets its sights on the next match against Jordan. Fans across the region are rallying behind the squad, proud of their progress and hungry for more success.', 'Photos/sport.jpg', 3, 5, '2023-07-12 06:05:09'),
(3, 'When Will the War on Gaza End', 'As the war on Gaza enters yet another harrowing phase, the world continues to ask the same haunting question: When will it end? The conflict, which has claimed thousands of lives and displaced entire communities, shows no signs of a definitive resolution. Despite growing international pressure, political deadlock and humanitarian catastrophe persist.\n\nIn recent weeks, ceasefire talks have resumed intermittently in Cairo and Doha, with negotiators from multiple regional and global powers attempting to broker a deal between Israel and Palestinian factions. Yet, with every round of discussion comes renewed violence on the ground, casting doubt on the sincerity or sustainability of any agreement reached.\n\nFor civilians in Gaza, the question is no longer political — it is deeply personal. Streets lie in ruins, families live in shelters or beneath makeshift tents, and basic necessities like clean water, electricity, and medical supplies are increasingly scarce. Local journalist Nour Hamdan, reporting from Rafah, described the situation as “a slow death unfolding in real time.”\n\nHuman rights organizations continue to call for an immediate and unconditional ceasefire. The International Coalition for Justice in Palestine released a statement urging world governments to intervene diplomatically and provide humanitarian corridors. “This war cannot be allowed to continue indefinitely,” the statement read. “Peace is not a privilege — it is a right.”\n\nDespite growing condemnation from global civil society and protests in capitals across Europe, the mechanisms of war remain active. The Israeli government insists on conditions it deems necessary for “long-term security,” while Palestinian representatives demand an end to occupation, blockade, and collective punishment.\n\nSome analysts believe that a ceasefire could be possible within the next few months, especially with increasing pressure from the United Nations and neighboring Arab states. Others fear that without a complete shift in strategy or leadership on both sides, the war may continue far beyond 2025.\n\nAs the conflict drags on, so too does the suffering of millions. And while the world waits for a political resolution, the people of Gaza continue to live a daily reality defined by uncertainty, grief, and endurance.', 'Photos/politics.jpg', 5, 3, '2025-06-07 08:37:36'),
(4, 'The Latest Microsoft Releases', '\nMicrosoft has been bustling this July with updates across its software, hardware, AI ecosystem, and support tools—underscoring its strategic pivot toward AI-powered platforms and enterprise readiness.\n\n1. AI Philanthropy in Education\nIn a bold move, Microsoft announced a $4 billion philanthropic program over five years to integrate AI and cloud tools into education. The initiative, aimed at training 20 million people from early schooling to technical college, will launch the Elevate Academy and a new National Academy for AI Instruction to upskill 400,000 teachers globally alongside partners like OpenAI and Anthropic \npartner.microsoft.com\n+1\nThe Verge\n+1\nTechRadar\n.\n\n2. Microsoft Build 2025 Highlights\nBuild 2025, held in May, brought over 50 new developer tools and updates, including:\n\nCopilot Studio and Microsoft 365 Copilot Tuning for smarter productivity.\n\nWindows AI Foundry and new local AI agent features.\n\nLaunch of open-source Windows Subsystem for Linux (WSL).\n\nIntroduction of NLWeb protocol for conversational web \nPolygon\n+5\nTom\'s Guide\n+5\nSource\n+5\nويكيبيديا\n+4\nSource\n+4\nThe Times of India\n+4\n.\n\n3. Windows 11 & Team Enhancements\n\nWindows 11 is rolling out a black Screen of Death (BSOD) plus new Quick Machine Recovery—currently via the Release Preview \nThe Verge\n+1\nويكيبيديا\n+1\n.\n\nThe July “Patch Tuesday” update (KB5062553) fixed over 130 vulnerabilities, added enterprise features like taskbar icon resizing and enhanced Copilot+ “Ask” actions \nSource\n+15\npetri.com\n+15\nthurrott.com\n+15\n.\n\nMicrosoft is previewing AI-powered dynamic wallpapers in Windows 11 builds—a visually responsive concept still under early development \nTechRadar\n.\n\n4. Office & Teams Updates\n\nJuly brought new security and feature updates across Office 2016, SharePoint, and OneNote (KB 5002745–KB 5002751) \nsupport.microsoft.com\n.\n\nTeams now supports threaded conversations, a “followed threads” view, multi-emoji reactions, and improved GIF commands in public preview \nThe Verge\n.\n\n5. Enterprise Licensing & Partner Programs\n\nThree-year subscription SKUs launched on June 1: E3, E5, and Teams Enterprise—with promotions and discounts \nlearn.microsoft.com\n.\n\nA July 9 update adjusted pricing/licensing of on-premises CAL suites, pushing price increases to September 2025 \nthezdi.com\n+2\nlearn.microsoft.com\n+2\npetri.com\n+2\n.\n\nThe Microsoft AI Cloud Partner Program rolled out new playbooks, partner assets for Copilot, and upcoming FY26 events \nyoutube.com\n+2\npartner.microsoft.com\n+2\nreddit.com\n+2\n.\n\n6. Mixed Reality & Quantum Announcements\n\nMicrosoft Mesh received a version update (v5.2512.5.0) on July 4, expanding immersive collaboration \nويكيبيديا\n.\n\nThe Majorana 1 chip prototype marks a promising step toward topological quantum computing—fitting eight qubits and showing signs of hosting Majorana zero modes \nويكيبيديا\n.\n\n7. Server & Cloud Infrastructure\n\nWindows Server 2025, released Nov 2024, continues under mainstream support; includes post-quantum crypto and updated admin tools \nويكيبيديا\n+1\nويكيبيديا\n+1\n.\n\nMicrosoft reaffirmed its $80 billion 2025 investment in AI-enabled data centers, underscoring its infrastructure commitment \nreuters.com\n.\n\n🔍 Bottom Line\nJuly 2025 proves to be a defining month for Microsoft: heavy on AI integration, governance, and cloud scaling. Major moves include enhancing education, securing enterprise environments, updating productivity tools, and pioneering in quantum and mixed reality. These releases reflect a comprehensive strategy to cement Microsoft’s leadership in the AI-driven tech landscape.', 'Photos/tecnology.jpg', 4, 7, '2022-02-17 02:19:02'),
(5, 'Education News', 'A new scholarship initiative has recently been launched to support Gaza students amid the ongoing educational crisis. Backed by international funding and collaborations, the program aims to offer renewed hope and academic opportunities to those affected.\n\nWhat’s the goal?\nThe primary objective of the program is to connect talented students from Gaza with fully funded university opportunities abroad. By removing financial and administrative barriers, the new initiative helps recipients pursue undergraduate and postgraduate studies in countries including France, the UK, Ireland, the United States, and beyond.\n\nHow does it work?\nStudents from Gaza—whether currently residing in Gaza or displaced—can apply via official portals. Programs such as France’s Excellence Scholarship cover tuition, monthly stipends (~€860 for bachelor’s and master’s, €1,690 for doctoral candidates), travel, health insurance, and student housing support \nReddit\n+6\nifporient.org\n+6\nCenter for Arab American Philanthropy\n+6\n.\nMeanwhile, the University of Sheffield in the UK offers a Postgraduate Taught Scholarship, fully funding tuition, accommodation, and a £5,000 maintenance stipend for one Gaza student starting in September 2025 \nscholyhub.com\n+1\nMakeoverarena\n+1\n.\n\nWho’s eligible?\nGazan nationals enrolled in recognized degree programs—or displaced students with prior residency in Gaza before October 2023—are encouraged to apply \nMakeoverarena\n+2\nscholyhub.com\n+2\niffgaza.org\n+2\n. Applicants typically need strong academic records, English proficiency, and clear educational goals.\n\nOther global efforts\nIreland has also announced fully funded master’s scholarships for Palestinian students under its Ireland-Palestine Scholarship Programme (IPSP), covering flights, tuition, visa fees, and a €700 monthly stipend for students from Gaza and the West Bank \niffgaza.org\n+15\ntrtworld.com\n+15\nReddit\n+15\n. Meanwhile, organizations like Scholarships for Ghazza offer mentorship, application support, and access to global opportunities, having assisted nearly 500 students so far \nscholarshipsforghazza.org\n+1\nscholarshipsforghazza.org\n+1\n.\n\nWhy it matters\nWith Gaza’s academic infrastructure devastated—most universities damaged or destroyed—the initiative provides a lifeline for students who might otherwise lose years of education \nscholarshipsforghazza.org\n+2\nCenter for Arab American Philanthropy\n+2\nscholarshipsforghazza.org\n+2\n. By investing in education, the program empowers a generation facing immense challenges, offering both hope and practical paths forward.', 'Photos/OIP.jpg', 1, 6, '2025-11-19 05:20:21'),
(6, 'Art News', 'In a powerful moment of recognition for Palestinian creativity, young artist Layla Mansour has been awarded the 2025 Levant Regional Art Prize for her emotional mixed-media collection titled \"Beneath the Rubble\", inspired by life and resilience in Gaza.\n\nThe ceremony, held in Amman on July 12, brought together leading voices in Middle Eastern art. Mansour, 28, from Khan Younis, delivered a moving speech where she dedicated the award to \"every child who turned shattered walls into sketches and silence into stories.\"\n\nHer collection, a haunting blend of charcoal, fabric, and digital collage, was praised for its emotional depth and unflinching portrayal of the human cost of war. Judges described the work as “a heartbreaking and courageous reflection of loss, identity, and hope.”\n\nThis year’s competition drew over 700 submissions from across the region. Mansour’s work stood out for its narrative clarity and social urgency. One of her standout pieces, \"Mother\'s Voice in Ashes,\" has already been acquired by a European museum and is expected to tour internationally.\n\nArt critics and audiences alike have applauded the piece not only for its aesthetic strength but for amplifying the voices of Gaza\'s civilians through a deeply personal lens.\n\nMansour is now planning to launch a virtual exhibition to make her work accessible to Palestinians worldwide, particularly those unable to travel or leave Gaza due to current restrictions.', 'Photos/art.webp', 2, 2, '2025-07-15 03:50:41'),
(7, 'Sports News', 'In one of the most inspiring sports stories of the year, the Gaza Football Club has reached the final of the 2025 Palestinian National Championship, following a series of commanding performances that captured the hearts of fans across the region.\n\nThe semi-final match, played in Hebron on July 10, saw Gaza FC defeat Nablus United 3–1 in a game full of energy, teamwork, and determination. Striker Yousef Al-Hattab led the charge with two goals, while midfielder Rami Shaheen controlled the pace with precision passing and tactical awareness.\n\nCoach Amr Dabbagh, speaking after the match, credited the team’s success to their unity and mental strength: “These players carry the spirit of Gaza with them on every blade of grass. They’re not just playing football—they’re playing for something far greater.”\n\nGaza FC’s journey to the final has been nothing short of remarkable, especially considering the logistical challenges the team faced. Frequent travel restrictions, lack of training facilities, and limited resources have made preparation difficult. Yet the team continued to shine, displaying both skill and grit throughout the tournament.\n\nThe upcoming final, scheduled for July 17 in Ramallah, will pit Gaza FC against reigning champions Al-Quds SC. Fans are anticipating a highly emotional showdown, with many hoping for Gaza’s first national title in over a decade.\n\nNo matter the result, Gaza’s team has already inspired a new generation of athletes and reminded the nation that excellence can still rise from adversity.', 'Photos/sport.webp', 3, 1, '2025-07-15 03:50:41');

-- --------------------------------------------------------

--
-- بنية الجدول `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`) VALUES
(2, 'Art'),
(1, 'Education'),
(6, 'Entertainment'),
(5, 'Politics'),
(3, 'Sports'),
(4, 'Technology');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `role`) VALUES
(1, 'admin', 'admin@example.com', '0192023a7bbd73250516f069df18b500', 'admin'),
(2, 'Yousef Barakat', 'yousef.barakat@example.com', 'Yb2025pass', 'user'),
(3, 'Nour Abdeen', 'nour.abdeen@example.com', 'NAb1987', 'user'),
(4, 'Ahmad Nassar', 'ahmad.nassar@example.com', 'AhN1234', 'user'),
(5, 'Lama Al-Taher', 'lama.altaher@example.com', 'Lama2025', 'user'),
(6, 'Tariq Jaber', 'tariq.jaber@example.com', 'TJgaza_21', 'user'),
(7, 'Rana Khaldi', 'rana.khaldi@example.com', 'Rk2025', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `author_id` (`author_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `article_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `fk_articles_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_articles_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
