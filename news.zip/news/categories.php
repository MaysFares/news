<?php
$host = "localhost";
$dbname = "news_db1";
$username = "root";
$password = "";


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($category_id <= 0) {
    echo "Invalid category ID.";
    exit;
}

$sql_cat = "SELECT category_name FROM categories WHERE category_id = ?";
$stmt_cat = $conn->prepare($sql_cat);
$stmt_cat->bind_param("i", $category_id);
$stmt_cat->execute();
$result_cat = $stmt_cat->get_result();

if ($result_cat->num_rows == 0) {
    echo "Category not found.";
    exit;
}

$category = $result_cat->fetch_assoc();

$sql_articles = "SELECT 
    articles.article_id,
    articles.title,
    articles.content,
    articles.image_url,
    articles.published_date,
    users.username AS author
FROM articles
JOIN users ON articles.author_id = users.user_id
WHERE articles.category_id = ?
ORDER BY articles.published_date DESC";

$stmt_articles = $conn->prepare($sql_articles);
$stmt_articles->bind_param("i", $category_id);
$stmt_articles->execute();
$result_articles = $stmt_articles->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Category: <?= htmlspecialchars($category['category_name']) ?></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      padding: 20px;
    }
    h1 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }
    .cards-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }
    .card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      width: 280px;
      overflow: hidden;
      text-decoration: none;
      color: inherit;
      transition: transform 0.2s ease;
      display: flex;
      flex-direction: column;
      cursor: pointer;
    }
    .card:hover {
      transform: translateY(-8px);
      box-shadow: 0 8px 24px rgba(0,0,0,0.15);
    }
    .card img {
      width: 100%;
      height: 160px;
      object-fit: cover;
      border-bottom: 1px solid #ddd;
    }
    .card-content {
      padding: 15px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }
    .card-title {
      font-weight: bold;
      font-size: 1.2em;
      margin-bottom: 10px;
      flex-shrink: 0;
    }
    .card-excerpt {
      color: #666;
      font-size: 0.9em;
      line-height: 1.3;
      flex-grow: 1;
    }
    @media(max-width: 600px) {
      .cards-container {
        flex-direction: column;
        align-items: center;
      }
      .card {
        width: 90%;
      }
    }
  </style>
</head>
<body>

  <h1>Category: <?= htmlspecialchars($category['category_name']) ?></h1>

  <?php if ($result_articles->num_rows > 0): ?>
    <div class="cards-container">
      <?php while ($article = $result_articles->fetch_assoc()): ?>
        <a href="article.php?id=<?= $article['article_id'] ?>" class="card" title="<?= htmlspecialchars($article['title']) ?>">
          <?php if (!empty($article['image_url'])): ?>
            <img src="<?= htmlspecialchars($article['image_url']) ?>" alt="<?= htmlspecialchars($article['title']) ?>" />
          <?php else: ?>
            <img src="default-image.jpg" alt="No image available" />
          <?php endif; ?>
          <div class="card-content">
            <div class="card-title"><?= htmlspecialchars($article['title']) ?></div>
            <div class="card-excerpt"><?= htmlspecialchars(substr(strip_tags($article['content']), 0, 120)) ?>...</div>
          </div>
        </a>
      <?php endwhile; ?>
    </div>
  <?php else: ?>
    <p style="text-align:center; font-size:1.1em; color:#555;">No articles found in this category.</p>
  <?php endif; ?>

</body>
</html>

<?php
$stmt_cat->close();
$stmt_articles->close();
$conn->close();
?>

