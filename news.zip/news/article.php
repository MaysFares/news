<?php
$host = "localhost";
$dbname = "news_db1";
$username = "root";
$password = "";


$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed" . $conn->connect_error);
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $article_id = intval($_GET['id']);

    $sql = "
    SELECT articles.title, articles.content, articles.image_url, articles.published_date, categories.category_name, users.username AS author
    FROM articles
    JOIN categories ON articles.category_id = categories.category_id
    JOIN users ON articles.author_id = users.user_id
    WHERE articles.article_id = ?
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $article_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $article = $result->fetch_assoc();
    } else {
        $error = "Article not found";
    }

    $stmt->close();
} else {
    $error = "Invalid article ID";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>
    <?php 
    if (isset($article)) {
        echo htmlspecialchars($article['title']);
    } else {
        echo "Error displaying the article";
    }
    ?>
</title>
<style>
  body { font-family: Arial, sans-serif; padding: 20px; direction: rtl; }
  img { max-width: 600px; display: block; margin-bottom: 20px; }
  .error { color: red; }
  .Contanier {
    max-width: 800px;
    margin: 40px auto;
    padding: 30px;
    background-color: #ffffff;
    border-radius: 16px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
  }

  .Contanier h1 {
    font-size: 32px;
    margin-bottom: 20px;
    color: #222;
    border-bottom: 2px solid #f0f0f0;
    padding-bottom: 10px;
    text-align: center;
  }

  .Contanier img {
    width: 100%;
    max-height: 400px;
    object-fit: cover;
    border-radius: 12px;
    margin: 20px auto;
  }

  .Contanier p {
    margin: 10px 0;
  }

  .Contanier strong {
    color: #555;
  }

  .Contanier small {
    color: #888;
  }

  .Contanier div:last-child {
    margin-top: 20px;
    padding-top: 15px;
    border-top: 1px solid #eee;
  }
</style>
</head>
<body>

<?php if (isset($error)): ?>
  <p class="error"><?= htmlspecialchars($error) ?></p>
<?php else: ?>
  <div class="Contanier">
    <h1><?= htmlspecialchars($article['title']) ?></h1>
    <?php if (!empty($article['image_url'])): ?>
      <img src="<?= htmlspecialchars($article['image_url']) ?>" alt="<?= htmlspecialchars($article['title']) ?>">
    <?php endif; ?>
    <p><strong>Category : </strong> <?= htmlspecialchars($article['category_name']) ?></p>
    <p><strong>Author : </strong> <?= htmlspecialchars($article['author']) ?></p>
    <p><small>Published Date : <?= htmlspecialchars($article['published_date']) ?></small></p>
    <div><?= nl2br(htmlspecialchars($article['content'])) ?></div>
  </div>
<?php endif; 
?>


</body>
</html>
